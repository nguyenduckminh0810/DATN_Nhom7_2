package com.auro.auro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuroApplicationTests {

	@Test
	void contextLoads() {
	}

}
